package com.example.demo.the.cafe;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoTheCafeApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoTheCafeApplication.class, args);
		System.err.println("project running");
	}

}
